//import java.io.FileNotFoundException;
//
//public class BlindRobot extends SearchProblem {
//    // coordinate of goal
//    static MazeProblem MazeWorld;
//    static char[][] world;
//    int rows, cols, goalX, goalY;
//
//    public BlindRobot(int gx, int gy, int r, int c, MazeProblem w)
//            throws FileNotFoundException {
//        rows = r;
//        cols = c;
//        goalX = gx;
//        goalY = gy;
//        MazeWorld = w;
//        world = MazeWorld.world;
////        MazeWorld.mazeToString();
////        MazeWorld.printMaze();
//        startNode = new MultiRobot.RobotNode(startCoords);
//
//    }
//}